package com.example.imagesteganography.fragments;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextEncodingCallback;
import com.ayush.imagesteganographylibrary.Text.ImageSteganography;
import com.ayush.imagesteganographylibrary.Text.TextEncoding;
import com.example.imagesteganography.Choosepdf;
import com.example.imagesteganography.MainActivity;
import com.example.imagesteganography.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;


public class Encodefragment extends Fragment implements TextEncodingCallback {


    MaterialButton encode, saveimage, chooseimage, choosepdf;

    private static final int SELECT_PICTURE = 100;
    private static final int SELECT_PDF = 12;
    private static final String TAG = "Encode Class";
    private static String filepathname;
    //Created variables for UI
    private TextView whether_encoded;
    private ImageView imageView;
    private  TextInputLayout message, secret_key ;
    //Objects needed for encoding
    private TextEncoding textEncoding;
    private ImageSteganography imageSteganography;
    private ProgressDialog save;
    private Uri filepath;
    //Bitmaps
    private Bitmap original_image;
    private Bitmap encoded_image;
    private int count = 2;

    public Encodefragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_encodefragment, container, false);


        message = view.findViewById(R.id.message);
        secret_key = view.findViewById(R.id.secretkey);
        encode = view.findViewById(R.id.encode);
        saveimage = view.findViewById(R.id.saveimage);
        chooseimage = view.findViewById(R.id.chooseimage);
        imageView = view.findViewById(R.id.imageview);
        whether_encoded = view.findViewById(R.id.whether_encoded);
        choosepdf = view.findViewById(R.id.choosepdf);

//
//        MainActivity mainActivity = (MainActivity) getActivity();
//        Bundle bundle = mainActivity.getMyData();
//        if(!bundle.isEmpty()) {
//            filepathname = bundle.getString("filepath");
//            message.getEditText().setText(bundle.getString("filepath"));
//        }


        checkAndRequestPermissions();


        chooseimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageChooser();
            }
        });

        choosepdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Pdfchooser();
//                startActivity(new Intent(getContext(), Choosepdf.class));
            }
        });

        encode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                whether_encoded.setText("");
                if (filepath != null) {
                    if (message.getEditText().getText() != null) {

                        //ImageSteganography Object instantiation
                        imageSteganography = new ImageSteganography(message.getEditText().getText().toString(),
                                secret_key.getEditText().getText().toString(),
                                original_image);
                        //TextEncoding object Instantiation
                        textEncoding = new TextEncoding(getActivity(), Encodefragment.this);
                        //Executing the encoding
                        textEncoding.execute(imageSteganography);
                    }
                }
            }
        });

        saveimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Bitmap imgToSave = encoded_image;
                Thread PerformEncoding = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        saveToInternalStorage(imgToSave);
                    }
                });
                save = new ProgressDialog(getContext());
                save.setMessage("Saving, Please Wait...");
                save.setTitle("Saving Image");
                //required to prevent dialog from disappearing
                save.setIndeterminate(false);
                save.setCancelable(false);
                save.show();
                PerformEncoding.start();
            }
        });


        return view;
    }

    private void ImageChooser() {

//        Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//        startActivityForResult(pickPhoto , 1);
//        Intent intent = new Intent();
////        intent.setAction(Intent.ACTION_GET_CONTENT);
////        intent.setType("image/*");
////        startActivityForResult(intent, 3);
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);

        Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, SELECT_PICTURE);


    }

    private void Pdfchooser() {

        Intent intent  = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, SELECT_PDF);


    }
    @SuppressLint("Range")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        //Image set to imageView
        if (requestCode == SELECT_PICTURE && resultCode == RESULT_OK && null != data) {

            if (requestCode == SELECT_PICTURE && resultCode == RESULT_OK && data != null && data.getData() != null) {

                filepath = data.getData();
                try {
                    original_image = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), data.getData());
                    Log.i("image-->>>",original_image.toString());
                    imageView.setImageBitmap(original_image);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }
        }

        if (requestCode == SELECT_PDF && resultCode == RESULT_OK && null != data) {
            Uri selectedpdf = data.getData();
            String path = selectedpdf.toString();

            String pdfname = null;
            if (path.startsWith("content://")) {
                Cursor cursor = null;
                try {
                    cursor = getContext().getContentResolver().query(selectedpdf, null,
                            null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        pdfname = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                        File file = new File(Environment.
                                getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                                +File.separator+pdfname);
                        message.getEditText().setText(selectedpdf.getPath());
                        extractPDF(file.toString());

                    }
                } finally {
                    cursor.close();
                }
            }
//            String[] filePathColumn = { MediaStore.Images.Media.DATA };
//            Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
//            cursor.moveToFirst();
//            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//            String picturePath = cursor.getString(columnIndex);
//            cursor.close();
//            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        }

    }

    private void extractPDF(String path) {
        try {
            // creating a string for
            // storing our extracted text.
            String extractedText = "";

            // creating a variable for pdf reader
            // and passing our PDF file in it.
            PdfReader reader = new PdfReader(path);

            // below line is for getting number
            // of pages of PDF file.
            int n = reader.getNumberOfPages();

            // running a for loop to get the data from PDF
            // we are storing that data inside our string.
            for (int i = 0; i < n; i++) {
                extractedText = extractedText + PdfTextExtractor.getTextFromPage(reader, i + 1).trim() + "\n";
                // to extract the PDF content from the different pages
            }

            // after extracting all the data we are
            // setting that string value to our text view.
            message.getEditText().setText(extractedText);

            // below line is used for closing reader.
            reader.close();
        } catch (Exception e) {
            // for handling error while extracting the text file.
            message.getEditText().setText("Error found is : \n" + e);
            count = count - 1;
            Toast.makeText(getContext(), "Please Enable Permission to ALLOW ALL FILES ACCESS or Please select pdf from downloads folder only", Toast.LENGTH_SHORT).show();
            if (count == 0 ) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getContext().getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }
    }
    public ArrayList<String> searchPdfInExternalStorage(File folder) {
        ArrayList<String> MyFiles = new ArrayList<String>();
        if (folder != null) {
            if (folder.listFiles() != null) {
                for (File file : folder.listFiles()) {

                    if (file.isFile()) {
                        //.pdf files
                        if (file.getName().contains(".pdf")) {
                            MyFiles.add(file.getName());
                            Log.d("fileName-------", "" + file.getPath());

                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        return MyFiles;
    }

    private void saveToInternalStorage(Bitmap bitmapImage) {
        OutputStream fOut;
        File file = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), System.currentTimeMillis() + ".PNG"); // the File to save ,

        if (file.exists()) {
            file.delete();
        }
        try {
            fOut = new FileOutputStream(file);
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fOut);// saving the Bitmap to a file
            fOut.flush(); // Not really required
            fOut.close(); // do not forget to close the stream
            whether_encoded.post(new Runnable() {
                @Override
                public void run() {
                    save.dismiss();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkAndRequestPermissions() {
        int permissionWriteStorage = ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int ReadPermission = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (ReadPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(getActivity(), listPermissionsNeeded.toArray(new String[0]), 1);
        }
    }

    @Override
    public void onStartTextEncoding() {

    }

    @Override
    public void onCompleteTextEncoding(ImageSteganography imageSteganography) {
        //By the end of textEncoding

        if (imageSteganography != null && imageSteganography.isEncoded()) {
            encoded_image = imageSteganography.getEncoded_image();
            whether_encoded.setText("Encoded");
            imageView.setImageBitmap(encoded_image);
        }
    }
}