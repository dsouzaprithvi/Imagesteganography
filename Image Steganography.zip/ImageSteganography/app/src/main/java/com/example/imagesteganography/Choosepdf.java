package com.example.imagesteganography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.imagesteganography.fragments.Encodefragment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Choosepdf extends AppCompatActivity {

    ListView pdflistview;
    List<String> pdfarraylist = new ArrayList<>();
    ArrayList<String> pdfpatharraylist = new ArrayList<>();

    List<File> pdffile = new ArrayList<>();
    ArrayAdapter pdfarrayadapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosepdf);

        pdflistview = findViewById(R.id.pdf_list);

        display_pdf();

        pdflistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(Choosepdf.this, MainActivity.class);
                File file = new File(Environment.getExternalStorageDirectory()
                        + File.separator + "Adminmesages" + File.separator + pdfarraylist.get(i));
                intent.putExtra("Filepath", file.getPath());
                startActivity(intent);
            }
        });
    }

    public void display_pdf(){

        if (pdfarrayadapter != null){
            pdfarrayadapter.clear();
        }
//        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        pdfarraylist.addAll(searchPdfInExternalStorage(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString())));
//    pdffile.addAll(searchPdffileInExternalStorage(new File(Environment.getExternalStorageDirectory()
//            + File.separator + "Adminmesages")));

        if ( pdfarraylist.size() < 1) {
            Toast.makeText(Choosepdf.this, "Please Enable Permission to ALLOW ALL FILES ACCESS", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivity(intent);
        }
        pdfarrayadapter = new ArrayAdapter(Choosepdf.this, android.R.layout.simple_list_item_1, pdfarraylist);

        Log.i("pdfs----....>>>", pdfarraylist.toString());

        pdflistview.setAdapter(pdfarrayadapter);

    }

    public ArrayList<String> searchPdfInExternalStorage(File folder) {
        ArrayList<String> MyFiles = new ArrayList<String>();
        if (folder != null) {
            if (folder.listFiles() != null) {
                for (File file : folder.listFiles()) {

                    if (file.isFile()) {
                        //.pdf files
                        if (file.getName().contains(".pdf")) {
                            MyFiles.add(file.getName());
                            Log.d("fileName-------", "" + file.getPath());

                        }
                    } else {
                        continue;
                    }
                }
            }
        }
        return MyFiles;
    }
}