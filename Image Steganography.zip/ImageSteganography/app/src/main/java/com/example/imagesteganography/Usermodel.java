package com.example.imagesteganography;

public class Usermodel {

    String uid, mobilenumber;

    public Usermodel(String uid, String mobilenumber) {
        this.uid = uid;
        this.mobilenumber = mobilenumber;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }
}
