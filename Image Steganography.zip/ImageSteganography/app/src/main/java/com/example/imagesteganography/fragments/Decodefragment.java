package com.example.imagesteganography.fragments;

import static android.app.Activity.RESULT_OK;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextDecodingCallback;
import com.ayush.imagesteganographylibrary.Text.ImageSteganography;
import com.ayush.imagesteganographylibrary.Text.TextDecoding;
import com.example.imagesteganography.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Decodefragment extends Fragment implements TextDecodingCallback {


    private static final int SELECT_PICTURE = 100;
    private static final String TAG = "Decode Class";
    //Initializing the UI components
    private TextView textView;
    private ImageView imageView;
    private TextInputLayout message;
    private TextInputLayout secret_key;
    private Uri filepath;
    //Bitmap
    private Bitmap original_image;

    MaterialButton decode;
    MaterialButton chooseimage, downloadimage;

    StorageReference httpsReference;
    FirebaseStorage storage;
    FirebaseAuth auth;
    FirebaseDatabase database;

    String url;

    File myFile;

    List<String> userslist = new ArrayList<>();
    ArrayAdapter useradapter;

    public Decodefragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_decodefragment, container, false);


        textView = view.findViewById(R.id.whether_encoded);
        message = view.findViewById(R.id.message);
        secret_key = view.findViewById(R.id.secretkey);

        chooseimage = view.findViewById(R.id.chooseimage);
        imageView = view.findViewById(R.id.imageview);
        decode = view.findViewById(R.id.decode);
        downloadimage = view.findViewById(R.id.downloadimage);

        useradapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, userslist);


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance("https://imagesteganography-8a35b-default-rtdb.asia-southeast1.firebasedatabase.app");
        storage = FirebaseStorage.getInstance();

        chooseimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageChooser();
            }
        });


        decode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (filepath != null) {

                    //Making the ImageSteganography object
                    ImageSteganography imageSteganography = new ImageSteganography(secret_key.getEditText().getText().toString(),
                            original_image);

                    //Making the TextDecoding object
                    TextDecoding textDecoding = new TextDecoding(getActivity(), Decodefragment.this);

                    //Execute Task
                    textDecoding.execute(imageSteganography);
                }
            }
        });

        downloadimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadimage();
            }
        });


        return view;
    }

    private void ImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Image set to imageView
        if (requestCode == SELECT_PICTURE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filepath = data.getData();
            Log.i("imagechooserpath",filepath.toString());
            try {
                original_image = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filepath);
                imageView.setImageBitmap(original_image);
            } catch (IOException e) {
                Log.d(TAG, "Error : " + e);
            }
        }

    }


    @Override
    public void onStartTextEncoding() {

    }

    @Override
    public void onCompleteTextEncoding(ImageSteganography imageSteganography) {
//By the end of textDecoding

        if (imageSteganography != null) {
            if (!imageSteganography.isDecoded())
                textView.setText("No message found");
            else {
                if (!imageSteganography.isSecretKeyWrong()) {
                    textView.setText("Decoded");
                    message.getEditText().setText("" + imageSteganography.getMessage());
                } else {
                    textView.setText("Wrong secret key");
                }
            }
        } else {
            textView.setText("Select Image First");
        }


    }

    private void downloadimage(){

        try{
//                    startRecording();
            database.getReference().child("users")
                    .child(auth.getCurrentUser().getPhoneNumber())
                    .child("imagelink").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    url = snapshot.getValue(String.class);
                    download();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Please Check File permission", Toast.LENGTH_SHORT).show();
        }
    }

    private void download() {

        //dialog();
       try {
           httpsReference = storage.getReferenceFromUrl(url);
           try {
               File localFile = new File(Environment.getExternalStorageDirectory(), "Imagedownload");
               if(!localFile.exists()) {
                   localFile.mkdirs();
               }

               myFile = new File(localFile,"encoded.png");

           } catch (Exception e) {
               Toast.makeText(getContext(), "Please Enable permission in settings", Toast.LENGTH_SHORT).show();
           }

           httpsReference.getFile(myFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
               @Override
               public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                   // Local temp file has been created
                   try {
                       Uri uri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3AImagedownload%2Fencoded.png");
                       original_image = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), Uri.fromFile(myFile));
                       imageView.setImageBitmap(original_image);
                       Log.i("downloadpath",Uri.fromFile(myFile).toString());
                       //ImageChooser();
                   } catch (IOException e) {
                       e.printStackTrace();
                   }


               }
           }).addOnFailureListener(new OnFailureListener() {
               @Override
               public void onFailure(@NonNull Exception exception) {
                   // Handle any errors
               }
           });
       } catch (Exception e) {
           e.printStackTrace();
           Toast.makeText(getContext(), "No image in server", Toast.LENGTH_SHORT).show();
       }

    }

    private void dialog() {
        Dialog builder = new Dialog(getContext());
        builder.requestWindowFeature(Window.FEATURE_NO_TITLE);
        builder.setCancelable(true);
        builder.setCanceledOnTouchOutside(false);
        builder.setContentView(R.layout.listofusers);
        builder.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        ListView userlist = builder.findViewById(R.id.userlist);

        userlist.setAdapter(useradapter);

        database.getReference().child("users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userslist.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    for (DataSnapshot buffer : dataSnapshot.getChildren()) {
                        if (buffer.getKey().equals("mobilenumber")) {
                            userslist.add(buffer.getValue(String.class));
                        }
                    }
                }
                useradapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        userlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });

        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
            }
        });

        builder.show();

    }
}