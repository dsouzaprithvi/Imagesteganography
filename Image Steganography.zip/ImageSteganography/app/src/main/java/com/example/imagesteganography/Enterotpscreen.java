package com.example.imagesteganography;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Enterotpscreen extends AppCompatActivity {

    Button getotpbutton;
    EditText enternumber;
    String mobilenumber;
    com.hbb20.CountryCodePicker countrycode;
    FirebaseAuth auth;

    private String[] PERMISSIONS;
    private static int counter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterotpscreen);

        getotpbutton = findViewById(R.id.buttongetotp);
        enternumber = findViewById(R.id.input_mobile_number);
        countrycode = findViewById(R.id.ccp);

        auth = FirebaseAuth.getInstance();


        PERMISSIONS = new String[]{
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
        };

        getotpbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!hasPermissions(Enterotpscreen.this, PERMISSIONS)) {
                    ActivityCompat.requestPermissions(Enterotpscreen.this, PERMISSIONS, 1);
                    counter = counter + 1;
                    if (counter >= 2) {
                        Toast.makeText(Enterotpscreen.this, "Please enable permissions in settings", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent();
                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                        intent.setData(uri);
                        startActivity(intent);

                    }
                }
                else{
                    if(!enternumber.getText().toString().trim().isEmpty()){
                        if((enternumber.getText().toString().trim()).length() == 10){
                            mobilenumber = countrycode.getSelectedCountryCodeWithPlus() + enternumber.getText().toString();
                            Log.i("Mobile",mobilenumber);
                            Intent intent = new Intent(Enterotpscreen.this, Verifyotpscreen.class);
                            intent.putExtra("mobile",mobilenumber);
                            startActivity(intent);
                        } else {
                            Toast.makeText( Enterotpscreen.this, "Please enter correct number", Toast.LENGTH_SHORT).show();
                        }

                    }else {
                        Toast.makeText( Enterotpscreen.this, "Enter mobile number", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        if(auth.getCurrentUser()!=null){

            Intent intent = new Intent(Enterotpscreen.this, MainActivity.class);
            startActivity(intent);
            finish();

        }


    }

    private boolean hasPermissions(Context context, String... PERMISSIONS){

        if(context != null && PERMISSIONS != null){

            for(String permission: PERMISSIONS){
                if(ActivityCompat.checkSelfPermission(context, permission) !=
                        PackageManager.PERMISSION_GRANTED){
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1 ){

            if(grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[2] == PackageManager.PERMISSION_GRANTED && grantResults[3] == PackageManager.PERMISSION_GRANTED){
                getotpbutton.setEnabled(true);
                Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "Permissions Denied go to settings to allow permissions", Toast.LENGTH_SHORT).show();
            }
        }
    }
}